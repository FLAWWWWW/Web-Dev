import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from './services/product.service';
import { Category } from './models/category.model';
import { Product } from './models/product.model';
import { ProductListComponent } from './components/product-list/product-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ProductListComponent],
  templateUrl: './app.component.html'
})
export class AppComponent {

  categories: Category[] = [];
  selectedCategoryId: number | null = null;

  constructor(private productService: ProductService) {
    this.categories = this.productService.getCategories();
  }

  selectCategory(id: number) {
    this.selectedCategoryId = id;
  }

  getFilteredProducts(): Product[] {
  if (!this.selectedCategoryId) return [];

  const all = this.productService.getProducts();
  console.log('ALL PRODUCTS:', all);
  console.log('Selected:', this.selectedCategoryId);

  const filtered = all.filter(p => p.categoryId === this.selectedCategoryId);
  console.log('FILTERED:', filtered);

  return filtered;
  }
}